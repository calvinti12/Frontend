<?php
$lang["frontend_prev"] = "Prev";
$lang["frontend_next"] = "Next";
$lang["frontend_month_1"] = "January";
$lang["frontend_month_2"] = "February";
$lang["frontend_month_3"] = "March";
$lang["frontend_month_4"] = "April";
$lang["frontend_month_5"] = "May";
$lang["frontend_month_6"] = "June";
$lang["frontend_month_7"] = "July";
$lang["frontend_month_8"] = "August";
$lang["frontend_month_9"] = "September";
$lang["frontend_month_10"] = "October";
$lang["frontend_month_11"] = "November";
$lang["frontend_month_12"] = "December";