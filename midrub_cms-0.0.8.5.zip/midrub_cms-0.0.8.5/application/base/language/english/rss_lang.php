<?php
$lang["rss_no_valid_xml_code"] = "No valid rss content was found.";
$lang["rss_xml_code_not_supported"] = "The rss feed is not supported.";
$lang["rss_xml_url_not_found"] = "The rss url was not found.";