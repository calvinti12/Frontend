<?php
// The mail sending protocol
$config['protocol'] = 'smtp';
// SMTP Server Address
$config['smtp_host'] = "smtp.gmail.com";
// SMTP Port
$config['smtp_port'] = "587";
// SMTP Username
$config['smtp_user'] = "";
// SMTP Password
$config['smtp_pass'] = "";
// Defines email formatting
$config['mailtype'] = 'html';
// Defines charset
$config['charset'] = 'utf-8';
// Defines priority
$config['priority'] = '1';
